
import pandas as pd

def ranker(database):

    stores_id = [0, 14, 19, 55, 129, 149, 160, 170, 215, 227]
    values_dict = {}

    # Read the Excel file with multiple sheets
    excel_file = pd.ExcelFile(database)

    # Iterate over each sheet
    for index, sheet_name in enumerate(excel_file.sheet_names):
        df = pd.read_excel(excel_file, sheet_name=sheet_name)
        value = df.iloc[34, 5]  # Row 21 (index 20) and Column 6 (index 5)
        values_dict[stores_id[index]] = value

    # Convert dictionary to list of items
    items = list(values_dict.items())

    # Remove the first item
    items.pop(0)

    # Convert back to dictionary
    values_dict = dict(items)

    sorted_dict = dict(sorted(values_dict.items(), key=lambda item: item[1], reverse=True))
    return sorted_dict
