
from flask import Flask, redirect, render_template, request
from helpers import ranker

# Configure application
app = Flask(__name__)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True



@app.route("/", methods=["GET", "POST"])
def index():
        return render_template("index.html")

@app.route("/ranking", methods=["GET", "POST"])
def ranking():
    ranking = None
    if request.method == "POST":
        file = request.files.get("file")
        if file:
            ranking = ranker(file)
        else:
            redirect("/")

    return render_template("ranking.html", ranking=ranking)
